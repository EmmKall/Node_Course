import express from 'express';
import path from 'path';

interface ServerOptions {
    port: number;
    public_path?: string;
}

export class Server {
    
    private readonly port: number;
    private readonly publicPath: string;

    private readonly app = express();
    
    constructor({port, public_path}: ServerOptions) {
        this.port = port;
        this.publicPath = public_path || 'public';
    }

    async start() {

        // Middleware

        // Public folders
        this.app.use(express.static(this.publicPath));

        this.app.use((req, res) => {
            const indexPath = path.join(`${__dirname}../../../${this.publicPath}/index.html`);
            console.log(req.url);
            res.sendFile(indexPath);
        });

        this.app.listen(this.port, () => {
            console.log(`Server started on port ${this.port}`);
        });
    }

}
